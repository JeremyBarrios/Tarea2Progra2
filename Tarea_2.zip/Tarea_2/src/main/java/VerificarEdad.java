import java.util.Scanner;

public class VerificarEdad {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Ingrese su edad: ");
        int edad = scanner.nextInt();
        
        if (edad >= 18) {
            System.out.println("El usuario es mayor de edad");
        } else {
                    System.out.println("El usuario es menor de edad");
                    
                    }
        
        scanner.close();
        }
    }
    
