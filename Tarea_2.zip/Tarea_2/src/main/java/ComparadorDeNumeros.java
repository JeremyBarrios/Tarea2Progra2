import java.util.Scanner;

public class ComparadorDeNumeros {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Solicitar al usuario que ingrese tres números
        System.out.print("Ingrese el primer numero entero: ");
        int numero1 = scanner.nextInt();
        
        System.out.print("Ingrese el segundo numero entero: ");
        int numero2 = scanner.nextInt();
        
        System.out.print("Ingrese el tercer numero entero: ");
        int numero3 = scanner.nextInt();
        
        // Comparar los números y encontrar el mayor
        int mayor;
        
        if (numero1 >= numero2 && numero1 >= numero3) {
            mayor = numero1;
        } else if (numero2 >= numero1 && numero2 >= numero3) {
            mayor = numero2;
        } else {
            mayor = numero3;
        }
        
        System.out.println("El mayor numero es: " + mayor);
        
        // Cerrar el scanner
        scanner.close();
    }
}
