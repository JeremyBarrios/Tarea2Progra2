import java.util.Scanner;

public class NombreDelMes{
    public static void main(String[] args){
    
        Scanner scanner = new Scanner(System.in);
        
        String[] meses = {
        
            "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", 
            "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
                
        };
     
        System.out.print("Ingrese el numero del mes:" );
        int numeroMes = scanner.nextInt();
        
        if(numeroMes >= 1 && numeroMes <= 12){
            
            String nombremes = meses[numeroMes - 1];
            System.out.println("El nombre del Mes es: " + nombremes);
            
        } else {
            System.out.println("Numero de mes invalido, ingrese un numero entre 1 y 12.");
        }
        
        scanner.close();
        
    }
}
